package com.example.gdprchat

import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ChatActivity : AppCompatActivity() {

    private lateinit var webhookUrl: String
    private lateinit var listAdapter: ArrayAdapter<String>
    private val messages = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        webhookUrl = intent.getStringExtra("WEBHOOK_URL") ?: ""

        val listView = findViewById<ListView>(R.id.chatListView)
        val input = findViewById<EditText>(R.id.editTextMessage)
        val sendButton = findViewById<Button>(R.id.buttonSend)

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, messages)
        listView.adapter = listAdapter

        sendButton.setOnClickListener {
            val userMsg = input.text.toString().trim()
            if (userMsg.isNotEmpty()) {
                messages.add("You: $userMsg")
                listAdapter.notifyDataSetChanged()
                input.setText("")
                sendMessageToN8N(userMsg)
            }
        }
    }

    private fun sendMessageToN8N(text: String) {
        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        val json = JSONObject()
        json.put("chatInput", text)

        val mediaType = "application/json".toMediaTypeOrNull()
        val requestBody = json.toString().toRequestBody(mediaType)

        Log.d("ChatActivity", "Sending to: $webhookUrl")
        Log.d("ChatActivity", "Payload: $json")

        val request = Request.Builder()
            .url(webhookUrl)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    messages.add("❌ Error: ${e.message}")
                    listAdapter.notifyDataSetChanged()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                val responseMsg = try {
                    JSONObject(body).getString("response")
                } catch (e: Exception) {
                    "❌ Invalid response or missing 'response' field"
                }

                runOnUiThread {
                    messages.add("Bot: $responseMsg")
                    listAdapter.notifyDataSetChanged()
                }
            }
        })
    }
}
