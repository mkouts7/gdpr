package com.example.gdprchat

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val urlInput = findViewById<EditText>(R.id.editTextUrl)
        val connectButton = findViewById<Button>(R.id.buttonConnect)

        connectButton.setOnClickListener {
            val url = urlInput.text.toString().trim()

            if (url.isNotEmpty() && url.startsWith("http")) {
                // IMPORTANT: URL must include the full webhook path
                val intent = Intent(this, ChatActivity::class.java)
                intent.putExtra("WEBHOOK_URL", url)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please enter a valid ngrok webhook URL", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
