package com.example.gdprchat

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val urlInput = findViewById<EditText>(R.id.editTextUrl)
        val connectButton = findViewById<Button>(R.id.buttonConnect)

        connectButton.setOnClickListener {
            val url = urlInput.text.toString().trim()
            if (url.isNotEmpty()) {
                val intent = Intent(this, ChatActivity::class.java)
                intent.putExtra("WEBHOOK_URL", url)
                startActivity(intent)
            }
        }
    }
}
